#include "Station.hpp"
#include <string>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#ifndef UTILS_HPP
#define UTILS_HPP

std::string addressify(std::string id_logrado, 
                     std::string sigla_tipo, std::string nome_logra,
                     std::string numero_imo,std::string nome_bairr,
                     std::string nome_regio,std::string cep);


void getStationsFromFile(Station* estacoes,std::ifstream& stationsDataFile, int numberOfStations);

double dist(double x1, double y1, double x2, double y2);

#endif