#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <fstream>
#include "Station.hpp"

#ifndef NAIVE_HPP
#define NAIVE_HPP

// struct that contain the distance information between the origin location and
// each recharging location.
typedef struct knn
{
  double dist; // distance between origin location and recharging location
  int id;      // recharging   location id
} knn_t, *ptr_knn_t;

void printmap(ptr_knn_t kvet, int kmax, Station* estacoes, int numberOfStations, double originX, double originY);


// qsort comparison function between distances to recharging locations
int compareDistances(const void *a, const void *b);

int naive(Station* stations,const char **argv);


#endif