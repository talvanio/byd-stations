#include "../include/utils.hpp"
#include "../include/naive.hpp"
#include <fstream>
#include <iostream>
#include <sstream>

int main() 
{

    // Abrindo o arquivo de estações:
    std::string stationsDataPath = "../dados/geracarga.base";
    std::ifstream stationsDataFile(stationsDataPath);
    std::string numberOfStationsString;
    int numberOfStations;


    if(!stationsDataFile.is_open()) 
    {
        std::cerr << "Nao foi possivel abrir o arquivo indicado no caminho " << stationsDataPath;
        return 1;
    }
    std::getline(stationsDataFile,numberOfStationsString);
    numberOfStations = std::stoi(numberOfStationsString);



    Station* stations = new Station[numberOfStations+1];
    getStationsFromFile(stations,stationsDataFile,numberOfStations);

    std::string testCoordX = "610167.846027439";
    const char* testCoordXChar = testCoordX.c_str();

    std::string testCoordY = "7795602.43183451";
    const char* testCoordYChar = testCoordY.c_str();

    const char** coordinates = new const char*[2];
    coordinates[1] = testCoordXChar;
    coordinates[2] = testCoordYChar;


    std::cout<<std::endl;
    naive(stations,coordinates);
    




    
    delete[] stations;
    return(0);
}