#include "../include/Station.hpp"
#include "../include/utils.hpp"

// Construtores:

Station::Station()
{
    status = 'A';
};
Station::Station(std::string _address, double _x, double _y)
{
    status = 'A';
    address = _address;
    x = _x;
    y = _y;
};

void Station::ativar()
{
    status = 'A';
};

void Station::desativar()
{
    status = 'D';
};

// Getters e Setters:
char Station::getStatus() { return status; };
void Station::setStatus(char _status) { status = _status; };

std::string Station::getAddress() { return address; };
void Station::setAddress(std::string _address) { address = _address; };

double Station::getX() { return x; };
void Station::setX(double _x) { x = _x; };

double Station::getY() { return y; };
void Station::setY(double _y) { y = _y; };

std::string Station::getId() { return id; };
void Station::setId(std::string _id) { id = _id; };
